<?php
include("include/header.php");
?>
<main role="main">
	<div class="container">
		<!-- Example row of columns -->
		<div class="row">
			<div class="col-md-12">
				<h1> Projetos LInC:</h1>
					<h2>Projetos em andamento:</h2>
						<p id="projetos"> Data Science Game 2018 Online qualifiers </p><!--mesma formatação para o ID dos titulos de projeto-->
						<!-- Inserir projetos em andamento por nome e participantes e conteudo-->
				<h2>Projetos Finalizados: </h2>
					<p id="projetos"> Titanic Kernel Competicion : </p>
					<!-- Inserir projetos finalizados por nome e participantes e conteudo -->
			</div>
		</div>
		<hr>
	</div> <!-- /container -->
</main>
<?php
include("include/footer.php");
?>

