<?php
include("include/header.php");
?>
<main role="main">
	<div class="container">
		<!-- Example row of columns -->
		<div class="row">
			<div class="col-md-12">
				<!--bloco de textos -->
				<p>Teste para aparecer texto na pagina</p>
			</div>
		</div>
		<hr>
	</div> <!-- /container -->
</main>
<?php
include("include/footer.php");
?>

