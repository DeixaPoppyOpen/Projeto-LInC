<?php
include("include/header.php");
?>
<main role="main">
	<div class="container">
		<!-- Example row of columns -->
		<div class="row">
			<div class="col-md-12">
				<!-- bloco onde se encontram os membro do LInC ser uma bloco a parte -->
    <h1>Membros Ativos:</h1>
        <h2>Times 1: </h2>
            <p id="participantes">	Luis Gustavo (Capitão) </p> <!--coloca mesma formatação para o participantes pelo ID-->
            <p id="participantes">Nathalia Machado </p>
            <p id="participantes">Thiago Dias  </p>
            <p id="participantes">Pedro Afonso</p>
        <!-- inserir tambem projetos em que estão participando e periodo -->
    <h2>Time 2:</h2>
        <p id="participantes">Daniel <!-- Capitão ??--> </p>
        <p id="participantes">Pedro Kiyuna </p>
        <p id="participantes">Rafael </p>
        <p id="participantes">Felipe Matins </p>
        <h3>Orientador: <b>Ricardo Menezes</b></h3>

    <!-- inserir tambem projetos em que estão participando e periodo -->
    <h2>Membros Inativos:</h2>
    <!-- Inserir Ex-participantes do LInc e projetos em que atuaram -->
			</div>
		</div>
		<hr>
	</div> <!-- /container -->
</main>
<?php
include("include/footer.php");
?>

