	    <!-- Conteudo fim -->
	
    <footer class="container">
      <div class="row align-items-center">
        <div class="col-md-3">
			<a target="_blank" href="http://www.bcc.unifal-mg.edu.br/portal/">
				<img src="fotos/bcc_grande.jpg" alt="">
			</a>
        </div>
		
		<div class="col-md-6 " align="center" >
          <h1> LInC </h1>
		  <p> Av. Jovino Fernandes Sales, 2600 - Santa Clara </p>
		  <p>Alfenas/MG - CEP: 37133-840.</p>
		  <p>texto</p>		<!-- colocar local no predio --> 
		  <p>texto</p>		<!-- pedir telefone de contato -->
        </div>
		
		
			<div class="col-md-3">
				<a target="_blank" href="http://www.bcc.unifal-mg.edu.br/portal/">
					<img src="fotos/unifal_grande.jpg" alt="">
				</a>
			</div>
      </div>

    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/holder.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  

</body></html>